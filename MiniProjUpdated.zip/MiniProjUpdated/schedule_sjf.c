/**
 * Implementation of various scheduling algorithms.
 *
 * SJF scheduling
 */

#include <stdlib.h>
#include <stdio.h>

#include "task.h"
#include "list.h"
#include "cpu.h"

// reference to the head of the list
struct node *head = NULL;

// sequence counter of next available thread identifier
int nextTid = 0;

Task *selectNextTask();

// add a new task to the list of tasks
void add(char *name, int arrivalTime, int burst) 
{
    // first create the new task
    Task *newTask = (Task *) malloc(sizeof(Task));

    newTask->name = name;
    newTask->tid = nextTid++;
    newTask->arrivalTime = arrivalTime;
    newTask->burst = burst;

    // insert the new task into the list of tasks
    insert(&head, newTask);
}

/**
 * Run the SJF scheduler
 */
void schedule()
{
    sortTasks(&head);
	
	Task *current;
	
	//arrays to keep track of individual task specs
	int turnTimeArr[8];
	int waitTimeArr[8];
	int respTimeArr[8];
	float respRatioArr[8];
	
	int currentTime = 0; //tracks timing
	int totalWT = 0;     //tracks waiting time total for later avg calc
	int totalTT = 0;     //tracks turnaround time total for later avg calc
	int totalburst = 0;  //tracks burst time total for later avg calc
	int tasks = 0;		 //tracks number (total) of tasks
	
	
    // sanity checker
    traverse(head);

    while (head != NULL) {
        current = selectNextTask();

		//calcs response time from time it would start to when it arrived
		int respTime = currentTime - current->arrivalTime;
        run(current, current->burst);
		
		currentTime += current->burst; //updates current time to after complete execution
		int turnTime = currentTime - current->arrivalTime;
		int waitTime = turnTime - current->burst;
		float respRatio = (float) (waitTime + current->burst) / current->burst;
		
		turnTimeArr[current->tid] = turnTime;
		waitTimeArr[current->tid] = waitTime;
		respTimeArr[current->tid] = respTime;
		respRatioArr[current->tid] = respRatio;
		
		printf("   Current Time = %d time unit\n\n", currentTime);
		
		totalWT += waitTime;
		totalTT += turnTime;
		totalburst += current->burst;
		tasks++;
		
        delete(&head, current);
    }
    printf("Task|%-15s|%-10s|%-15s|%-15s\n", "Turnaround Time", "Wait Time", "Response Time", "Response Ratio");
	for (int i = 0; i < tasks; i++) {
		printf("T%-3d|%-15d|%-10d|%-15d|%-15.3f\n", i+1, turnTimeArr[i], waitTimeArr[i], respTimeArr[i], respRatioArr[i]);
	}
	printf("\n\n");
	
    float avgTT = (float) totalTT/tasks;
    float avgWT = (float) totalWT/tasks;
    float throughput = (float) totalburst/tasks;
    printf("%-20s|%-15s|%-15s\n", "Avg Turnaround Time", "Avg Wait Time", "Throughput");
	printf("%-20.3f|%-15.3f|%-15.3f\n", avgTT, avgWT, throughput);
    
}


/**
 * Returns the next task selected to run.
 */
Task *selectNextTask()
{
    return head->task;
}

