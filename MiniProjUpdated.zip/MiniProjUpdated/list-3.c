/**
 * Various list operations
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "list.h"
#include "task.h"

//add sort function here
void sortTasks(struct node **head) 
{
	if (head == NULL || (*head)->next == NULL) return;
	
	struct node *a, *b;
	Task *temp;
	
	for (a = (*head); a != NULL; a = a->next) 
	{
		for (b = a->next; b != NULL; b = b->next) 
		{
			if (a->task->burst > b->task->burst || (a->task->burst == b->task->burst && a->task->tid > b->task->tid))
			{
				temp = a->task;
				a->task = b->task;
				b->task = temp;
			}
		}
	}
}

// add a new task to the list of tasks
void insert(struct node **head, Task *newTask) 
{
    // add the new task to the list
    struct node *newNode = malloc(sizeof(struct node));

    newNode->task = newTask;
    newNode->next = *head;
    *head = newNode;
}

// delete the selected task from the list
void delete(struct node **head, Task *task) 
{
    struct node *temp;
    struct node *prev;

    temp = *head;
    // special case - beginning of list
    if (strcmp(task->name,temp->task->name) == 0) 
    {
        *head = (*head)->next;
    }
    else 
    {
        // interior or last element in the list
        prev = *head;
        temp = temp->next;
        while (strcmp(task->name,temp->task->name) != 0) 
        {
            prev = temp;
            temp = temp->next;
        }

        prev->next = temp->next;
    }
}

// traverse the list
void traverse(struct node *head) 
{
    struct node *temp;
    temp = head;

    while (temp != NULL) 
    {
        printf("[%s] [%d] [%d]\n",temp->task->name, temp->task->arrivalTime, temp->task->burst);
        temp = temp->next;
    }
}

